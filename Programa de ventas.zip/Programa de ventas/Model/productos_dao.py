from .conexion_db import conexion_db
from tkinter import messagebox

def crear_tabla():
    conexion = conexion_db()

    sql = """
    CREATE TABLE productos (
    id_productos INTEGER,
    nombre VARCHAR(100),
    cantidad INTEGER,
    precio INTEGER,
    tipo VARCHAR(100),
    PRIMARY KEY (id_productos AUTOINCREMENT)
)"""
    try:
        conexion.cursor.execute(sql)
        conexion.cerrar()
        titulo = "Crear registro"
        mensaje = "Se creo la tabla en la base de datos exitosamente."
        messagebox.showinfo(titulo, mensaje)

    except:
        titulo = "Crear registro"
        mensaje = "Esta tabla ya esta creada."
        messagebox.showwarning(titulo, mensaje)


def borrar_tabla():
    conexion = conexion_db()

    sql = "DROP TABLE productos"

    try:
        conexion.cursor.execute(sql)
        conexion.cerrar()
        titulo = "Borrar registro."
        mensaje = "Se elimino la tabla de la base de datos con exito."
        messagebox.showinfo(titulo, mensaje)
    
    except:
        titulo = "Borrar registro"
        mensaje = "No hay tabla para borrar"
        messagebox.showerror(titulo, mensaje)

class producto():
    def __init__(self, nombre, cantidad, precio, tipo):
        self.id_productos = None
        self.nombre = nombre
        self.cantidad = cantidad
        self.precio = precio
        self.tipo = tipo

def __str__(self):
        return (f"Productos[{self.nombre}, {self.cantidad}, {self.precio}, {self.tipo}]")

def guardar(self):
        conexion = conexion_db()

        sql = f"""INSERT INTO productos (nombre, cantidad, precio, tipo)
        VALUES("{self.nombre}", "{self.cantidad}", "{self.precio}", "{self.tipo}")"""

        try:
            conexion.cursor.execute(sql)
            conexion.cerrar()
        except:
            titulo = "Conexion al registro"
            mensaje = "La tabla productos no está creada en la base de datos."
            messagebox.showerror(titulo, mensaje)

def listar():
    conexion = conexion_db()

    lista_de_productos = []
    sql = "SELECT * FROM productos"

    try:
        conexion.cursor.execute(sql)
        lista_de_productos = conexion.cursor.fetchall()
        conexion.cerrar()
    
    except:
        titulo = "Conexion al registro"
        mensaje = "Crea la tabla en la base de datos."
        messagebox.showerror(titulo, mensaje)

    return lista_de_productos

def editar(producto, id_producto):
    conexion = conexion_db()
    sql = f"""UPDATE productos
    SET nombre = '{producto.nombre}', precio = '{producto.precio}', cantidad = '{producto.cantidad}', tipo = '{producto.tipo}'
    WHERE id_productos = {id_producto}"""

    try:
        conexion.cursor.execute(sql)
        conexion.cerrar()
    except:
        titulo = "Editar producto"
        mensaje = "Error al editar el producto en la base de datos."
        messagebox.showerror(titulo, mensaje)

def eliminar(id_productos):
    conexion = conexion_db()
    sql = f"DELETE FROM productos WHERE id_productos = {id_productos}"

    try:
        conexion.cursor.execute(sql)
        conexion.cerrar()
    except:
        titulo = "elimnar datos"
        mensaje = "No se pudo elimnar el registro"
        messagebox.showerror(titulo, mensaje)
