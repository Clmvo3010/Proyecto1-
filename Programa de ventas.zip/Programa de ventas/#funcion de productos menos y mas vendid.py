import tkinter as tk
from tkinter import messagebox

#funcion de productos menos y mas vendidos

def productos_mas_menos_vendidos(datos_ventas):

    if not datos_ventas:
        return "El diccionario de datos de ventas está vacío."

    mas_vendido = max(datos_ventas, key=datos_ventas.get)
    menos_vendido = min(datos_ventas, key=datos_ventas.get)

    return f"Producto más vendido: {mas_vendido}, Cantidad vendida: {datos_ventas[mas_vendido]}/nProducto menos vendido: {menos_vendido}, Cantidad vendida: {datos_ventas[menos_vendido]}"

datos_ventas_ejemplo = {"ProductoA": 50, "ProductoB": 30, "ProductoC": 80, "ProductoD": 20}
resultado = productos_mas_menos_vendidos(datos_ventas_ejemplo)
print(resultado)

#Funcion para calcular descuento

def calcular_descuento(precio_original, porcentaje_descuento):
    
    if 0 <= porcentaje_descuento <= 100:
        
        descuento = precio_original * (porcentaje_descuento / 100)
        
        precio_con_descuento = precio_original - descuento
        
        return precio_con_descuento
    else:
        return "Porcentaje de descuento no válido. Debe estar entre 0 y 100."

precio_original = 100.0
porcentaje_descuento = 20.0

precio_con_descuento = calcular_descuento(precio_original, porcentaje_descuento)
print(f"Precio original: Bs{precio_original}")
print(f"Porcentaje de descuento: {porcentaje_descuento}%")
print(f"Precio con descuento: Bs{precio_con_descuento}")

#funcion para calcular la ganancia mensual 

def calcular_ganancias_mensuales(ingresos_mensuales, gastos_mensuales):
   

    if len(ingresos_mensuales) != len(gastos_mensuales):
        return "Las listas de ingresos y gastos deben tener la misma longitud."

    ganancias_mensuales = []

    for ingreso, gasto in zip(ingresos_mensuales, gastos_mensuales):
        ganancia_neta = ingreso - gasto
        ganancias_mensuales.append(ganancia_neta)

    return ganancias_mensuales

ingresos = [5000, 6000, 7000, 8000, 9000]
gastos = [2000, 2500, 3000, 3500, 4000]

ganancias_mensuales = calcular_ganancias_mensuales(ingresos, gastos)

for i, ganancia_mes in enumerate(ganancias_mensuales, 1):
    print(f"Ganancia del mes {i}: Bs{ganancia_mes}")


#funcion de login de usuario
def login_usuario():
   
    base_datos_usuarios = {
        "Cesar": "clave123",
        "Luis": "Prueba123"
    }

    usuario_ingresado = input("Ingrese el nombre de usuario: ")
    contrasena_ingresada = input("Ingrese la contraseña: ")

    if usuario_ingresado in base_datos_usuarios and base_datos_usuarios[usuario_ingresado] == contrasena_ingresada:
        print(f"Bienvenido, {usuario_ingresado}!")
    else:
        print("Credenciales incorrectas. Inicio de sesión fallido.")

login_usuario()

